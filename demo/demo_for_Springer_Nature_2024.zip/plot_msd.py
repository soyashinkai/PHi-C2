import numpy as np
import matplotlib.pyplot as plt
# -----------------------------------------------------------------------------
DIR = "mESCs_observed_KR_chr1_130000000-135000000_res25000bp"
plt.rcParams["font.family"] = "Arial"
plt.rcParams["font.size"] = 36
# -----------------------------------------------------------------------------


def read_time_avemsd(n_start, n_end):
    data = np.zeros((600 + 1, 2))
    cnt = 0
    for n in range(n_start, n_end):
        data += np.loadtxt("{0:s}/data_MSD/n{1:d}.txt".format(DIR, n))
        cnt += 1
    data /= cnt
    return data
# -----------------------------------------------------------------------------


def main():
    data_Lrrn2 = read_time_avemsd(115, 118)
    data_Mapkapk2 = read_time_avemsd(42, 44)
    # -------------------------------------------------------------------------
    plt.figure(figsize=(12, 9))
    plt.gca().spines["right"].set_visible(False)
    plt.gca().spines["top"].set_visible(False)
    plt.gca().yaxis.set_ticks_position("left")
    plt.gca().xaxis.set_ticks_position("bottom")

    plt.xlim(-10, 1000)
    plt.ylim(0, 100)

    plt.xlabel(r"$\mathrm{\mathbf{\bar{t}}}$")
    plt.ylabel(r"$\mathrm{\mathbf{\overline{MSD} (\bar{t})}}$")

    plt.plot(data_Lrrn2[:401, 0], data_Lrrn2[:401, 1],
             label="Lrrn2", color=(1, 0, 0.5), lw=5)

    plt.plot(data_Mapkapk2[:401, 0], data_Mapkapk2[:401, 1],
             label="Mapkapk2", color=(0, 0.5, 1), lw=5)

    plt.legend(prop={"weight":"bold", "style":"italic"})
    plt.tight_layout()
    plt.savefig("{0:s}/data_MSD/figs/MSD_of_genes.svg".format(DIR))
    plt.close()
# -----------------------------------------------------------------------------


if __name__ == "__main__":
    main()
