import numpy as np
import matplotlib.pyplot as plt
# -----------------------------------------------------------------------------
DIR = "mESCs_observed_KR_chr1_130000000-135000000_res25000bp"
plt.rcParams["font.family"] = "Arial"
plt.rcParams["font.size"] = 36
# -----------------------------------------------------------------------------


def read_omega_avetan(n_start, n_end):
    data = np.zeros((600 + 1, 2))
    cnt = 0
    for n in range(n_start, n_end):
        data += np.loadtxt("{0:s}/data_rheology/n{1:d}.txt".format(DIR, n), usecols=[0, 7])
        cnt += 1
    data /= cnt
    return data
# -----------------------------------------------------------------------------


def main():
    data_Lrrn2 = read_omega_avetan(115, 118)
    data_Mapkapk2 = read_omega_avetan(42, 44)
    # -------------------------------------------------------------------------
    plt.figure(figsize=(12, 9))
    plt.gca().spines["right"].set_visible(False)
    plt.gca().spines["top"].set_visible(False)
    plt.gca().yaxis.set_ticks_position("left")
    plt.gca().xaxis.set_ticks_position("bottom")

    plt.xlim(-3, 0)
    plt.ylim(-0.3, 0.3)
    plt.yticks([-0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3])

    plt.xlabel(r"$\mathrm{\mathbf{log_{10} \bar{\omega}}}$")
    plt.ylabel(r"$\mathrm{\mathbf{log_{10} tan \delta(\bar{\omega})}}$")

    plt.plot(np.log10(data_Lrrn2[200:501, 0]), np.log10(data_Lrrn2[200:501, 1]),
             label="Lrrn2", color=(1, 0, 0.5), lw=5)

    plt.plot(np.log10(data_Mapkapk2[200:501, 0]), np.log10(data_Mapkapk2[200:501, 1]),
             label="Mapkapk2", color=(0, 0.5, 1), lw=5)

    plt.hlines(y=0, xmin=-3, xmax=0, color="black", linestyles="dashed")

    plt.legend(prop={"weight":"bold", "style":"italic"})
    plt.tight_layout()
    plt.savefig("{0:s}/data_rheology/figs/loss_tangent_of_genes.svg".format(DIR))
    plt.close()
# -----------------------------------------------------------------------------


if __name__ == "__main__":
    main()
