#!/bin/bash

# Set input name
NAME=mESCs_observed_KR_chr1_130000000-135000000_res25000bp

# Run the preprocessing
phic preprocessing --input ${NAME}.txt --res 25000 --plt-max-c 0.06

# Run the optimization
phic optimization --name ${NAME}

# Plot the optimized results
phic plot-optimization --name ${NAME} --res 25000 --plt-max-c 0.06 --plt-max-k-backbone 1.0 --plt-max-k 0.02 --plt-k-dis-bins 200 --plt-max-k-dis 400

# Run the 4D dynamics simulation
phic dynamics --name ${NAME} --interval 10 --frame 1000

# Run the 3D conformation sampleing
phic sampling --name ${NAME} --sample 1000

# Calculate the MSDs
phic msd --name ${NAME}

# Plot the spectrum of the MSDs
phic plot-msd --name ${NAME} --plt-upper 3 --plt-lower 0 --plt-max-log 2.0 --plt-min-log 0.5 --aspect 0.3

# Calculate the rheology features
phic rheology --name ${NAME}

# Plot the spectrum of the loss tangent
phic plot-tangent --name ${NAME} --plt-upper 0 --plt-lower -3 --plt-max-log 0.3 --aspect 0.3

